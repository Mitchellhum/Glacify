from datetime import date
import polars as pl

from glacier.base import ValidationBase
from glacier.settings import ValidationSettings
from glacier.wrappers import validation_check
from glacier.column import Column


class NewClass(ValidationBase):
    settings = ValidationSettings(strict=False)
    index: int = Column(name="Index", is_identifier=True)
    string_column: str = Column(name="String Column", strict=True)
    int_column: int = Column(name="Int Column")
    float_column: float = Column(name="Float Column", lt="")
    list_column: list[str] = Column(name="List Column")
    date_column: date = Column(name="Date Column", default="")


if __name__ == "__main__":
    dataframe = pl.read_csv("./test.csv", separator=";", infer_schema_length=0)
    model = NewClass()

    print(dataframe)

    model.validate(dataframe=dataframe)

    result = model.dump()

    print(result)
